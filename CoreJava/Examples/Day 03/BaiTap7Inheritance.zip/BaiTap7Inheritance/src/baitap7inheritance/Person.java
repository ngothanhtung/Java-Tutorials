/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baitap7inheritance;

/**
 *
 * @author softech
 */
public class Person {
    public String Name;
    public int Age;
    
    public void display() {
        System.out.println("Name: " + Name);
        System.out.println("Age: " + Age);
    }
    /*
    public void display(String title) {
        System.out.println(title);
        System.out.println("Name: " + Name);
        System.out.println("Age: " + Age);
    }
    */
    
}
